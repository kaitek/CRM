﻿namespace jll.emea.crm.Transliteration
{
    public interface IConverter
    {
        string Normalize(string source);
    }
}
