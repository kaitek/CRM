const path = require('path');
const webpack = require('webpack');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
//const CheckerPlugin = require('awesome-typescript-loader').CheckerPlugin;
const merge = require('webpack-merge');

module.exports = (env) => {
    const isDevBuild = !(env && env.prod);
    // Configuration in common to both client-side and server-side bundles
    const sharedConfig = () => ({
        stats: { modules: false },
        resolve: { extensions: ['.js', '.jsx', '.ts', '.tsx'] },
        output: {
            filename: '[name].js',
            publicPath: 'root/js' // Webpack dev middleware, if enabled, handles requests for this URL prefix
        },
        module: {
            rules: [
                { test: /\.tsx?$/, include: /app/, use: 'ts-loader' },//'awesome-typescript-loader?silent=true' },
                { test: /\.(png|jpg|jpeg|gif|svg)$/, use: 'url-loader?limit=25000' }
            ]
        }
    });

    // Configuration for client-side bundle suitable for running in browsers
    const clientBundleOutputDir = './root/js';
    const clientBundleConfig = merge(sharedConfig(), {
        entry: {
            'app1': './app/app1.tsx',
            'balance_dialog': './app/balance_dialog.tsx',
            'customer_view': './app/customer_view.tsx',
            'team_tree': './app/team_tree.tsx',
            'classifier': './app/classifier.tsx',
            'import_logins': './app/import_logins.tsx',
            'file_store': './app/file_store.tsx',
            'contact_rating': './app/contactRating.tsx',
            'incident_rating': './app/incident_rating.tsx',
            'userSettings_form': './app/userSettings_form.tsx',
            'pass_to_claim_success_alert': './app/pass_to_claim_success_alert.tsx',
            'duplicate_accounts': './app/duplicate_accounts.tsx',
            'quote_deactivation_dialog': './app/quote_deactivation_dialog.tsx',
            'tasks_close_dialog': './app/tasks_close_dialog.tsx',
            'editable_table': './app/editableTable.tsx',
            'opportunity_close_as_lost_dialog': './app/opportunity_close_as_lost_dialog.tsx',
            'lead_qualify_dialog': './app/lead_qualify_dialog.tsx'
        },
        module: {
            rules: [
                { test: /\.s?css$/, use: ['style-loader', isDevBuild ? 'css-loader' : 'css-loader?minimize', 'sass-loader'] }
            ]
        },
        output: { path: path.join(__dirname, clientBundleOutputDir) },
        plugins: [
            new webpack.ProvidePlugin({ Promise: ['promise-polyfill', 'default'] }),
            new webpack.DllReferencePlugin({
                context: __dirname, 
                manifest: require('./root/json/vendormanifest.json')
            })
        ].concat(isDevBuild ? [
            // Plugins that apply in development builds only
            new webpack.SourceMapDevToolPlugin({
                filename: '[file].map', // Remove this line if you prefer inline source maps
                moduleFilenameTemplate: path.relative(clientBundleOutputDir, '[resourcePath]') // Point sourcemap entries to the original file locations on disk
            })
        ] : [
            // Plugins that apply in production builds only
            new webpack.optimize.UglifyJsPlugin()
        ]),
        devServer: {
            contentBase: './root'
        }
    });

    const crmClientBundleConfig = merge(sharedConfig(),
        {
            entry: {
                crm: './app/crm.ts'
            },
            output: {
                path: path.join(__dirname, clientBundleOutputDir),
                devtoolModuleFilenameTemplate: path.relative(clientBundleOutputDir, '[resourcePath]')
            },
            plugins: isDevBuild ? [] : [new webpack.optimize.UglifyJsPlugin()],
            devtool: 'source-map'
        });
    return [clientBundleConfig, crmClientBundleConfig];
};