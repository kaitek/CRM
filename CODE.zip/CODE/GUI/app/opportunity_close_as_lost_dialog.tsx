import * as React from 'react';
import * as ReactDOM from 'react-dom';

import { Dialog } from './components/opportunity/closeAsLost/dialog'
 

ReactDOM.render(
    <Dialog />,
    document.getElementById('root')
);