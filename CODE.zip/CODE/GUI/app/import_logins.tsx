import * as React from 'react'
import * as ReactDOM from 'react-dom'
import { ImportLogins } from './components/import_logins'
import './components/import_logins/import_logins.scss'
ReactDOM.render(
    <ImportLogins />,
    document.getElementById('root')
);
