import * as React from 'react';
import { RouteComponentProps } from 'react-router';

export class Car extends React.Component<RouteComponentProps<{}>, {}> {
    public render() {
        return <div>
            <h1>Zzzzzz!</h1>
        </div>;
    }
}
