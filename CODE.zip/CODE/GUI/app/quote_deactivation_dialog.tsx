﻿import * as React from 'react';
import * as ReactDOM from 'react-dom';
import QuoteDeactivationForm from './components/quoteDeactivationForm';

ReactDOM.render(<QuoteDeactivationForm />,
    document.getElementById("root"));