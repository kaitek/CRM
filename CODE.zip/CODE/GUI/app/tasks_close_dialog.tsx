﻿import * as React from 'react';
import * as ReactDOM from 'react-dom';
import TasksCloseForm from './components/tasksCloseForm';

ReactDOM.render(<TasksCloseForm />,
    document.getElementById('root')
);